/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package readtest;

/**
 *
 * @author DanielVegaSantos
 */
public class ReadTest {

    /**
     * @param args the command line arguments
     */
    public static void main(String[] args) {
        Read f = new Read();
        f.createFiles("src/txts/text.txt");
        
    }
    
}
