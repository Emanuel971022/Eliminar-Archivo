package ufps.poo2.archivo;

public class ProcesaApp {

	public static void main(String[] args) {
		ProcesaTransaccion p = new ProcesaTransaccion();
		p.procesarArchivo("banco.txt");
	}
	
}
